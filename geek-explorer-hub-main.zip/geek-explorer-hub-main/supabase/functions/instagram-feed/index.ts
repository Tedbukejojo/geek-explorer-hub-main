import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface InstagramMedia {
  id: string;
  media_type: 'IMAGE' | 'VIDEO' | 'CAROUSEL_ALBUM';
  media_url: string;
  thumbnail_url?: string;
  permalink: string;
  caption?: string;
  timestamp: string;
  like_count?: number;
  comments_count?: number;
}

interface InstagramResponse {
  data: InstagramMedia[];
  paging?: {
    cursors: {
      before: string;
      after: string;
    };
    next?: string;
  };
}

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const accessToken = Deno.env.get('INSTAGRAM_ACCESS_TOKEN');
    
    if (!accessToken) {
      throw new Error('Instagram access token not configured');
    }

    // Get limit from query params (default 4)
    const url = new URL(req.url);
    const limit = url.searchParams.get('limit') || '4';

    // Fetch media from Instagram Graph API
    const fields = 'id,media_type,media_url,thumbnail_url,permalink,caption,timestamp,like_count,comments_count';
    const apiUrl = `https://graph.instagram.com/me/media?fields=${fields}&limit=${limit}&access_token=${accessToken}`;
    
    console.log('Fetching Instagram media...');
    
    const response = await fetch(apiUrl);
    
    if (!response.ok) {
      const errorData = await response.text();
      console.error('Instagram API error:', errorData);
      throw new Error(`Instagram API error: ${response.status}`);
    }

    const data: InstagramResponse = await response.json();
    
    // Format response for frontend
    const posts = data.data.map((media) => ({
      id: media.id,
      type: media.media_type,
      image: media.media_type === 'VIDEO' ? media.thumbnail_url : media.media_url,
      permalink: media.permalink,
      caption: media.caption || '',
      timestamp: media.timestamp,
      likes: media.like_count || 0,
      comments: media.comments_count || 0,
    }));

    console.log(`Successfully fetched ${posts.length} posts`);

    return new Response(
      JSON.stringify({ posts, success: true }),
      { 
        headers: { 
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    );
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error fetching Instagram feed:', errorMessage);
    
    return new Response(
      JSON.stringify({ 
        error: errorMessage, 
        success: false 
      }),
      { 
        status: 500,
        headers: {
          ...corsHeaders, 
          'Content-Type': 'application/json' 
        } 
      }
    );
  }
});
