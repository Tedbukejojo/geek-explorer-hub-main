import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface InstagramPost {
  id: string;
  type: 'IMAGE' | 'VIDEO' | 'CAROUSEL_ALBUM';
  image: string;
  permalink: string;
  caption: string;
  timestamp: string;
  likes: number;
  comments: number;
}

interface InstagramFeedResponse {
  posts: InstagramPost[];
  success: boolean;
  error?: string;
}

async function fetchInstagramFeed(limit: number = 4): Promise<InstagramPost[]> {
  const { data, error } = await supabase.functions.invoke<InstagramFeedResponse>(
    'instagram-feed',
    {
      body: {},
      headers: {
        'Content-Type': 'application/json',
      },
    }
  );

  if (error) {
    console.error('Error invoking instagram-feed function:', error);
    throw new Error(error.message);
  }

  if (!data?.success) {
    throw new Error(data?.error || 'Failed to fetch Instagram feed');
  }

  return data.posts;
}

export function useInstagramFeed(limit: number = 4) {
  return useQuery({
    queryKey: ['instagram-feed', limit],
    queryFn: () => fetchInstagramFeed(limit),
    staleTime: 1000 * 60 * 5, // 5 minutes
    retry: 1,
  });
}
