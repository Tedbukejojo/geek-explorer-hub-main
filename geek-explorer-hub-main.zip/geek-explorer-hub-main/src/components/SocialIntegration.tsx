import { Instagram, Youtube, Play, Heart, MessageCircle, Loader2, AlertCircle } from "lucide-react";
import { Button } from "./ui/button";
import { useInstagramFeed } from "@/hooks/useInstagramFeed";

// Fallback data for when API is not available
const fallbackInstagramPosts = [
  { id: "1", image: "https://images.unsplash.com/photo-1612287230202-1ff1d85d1bdf?w=400&q=80", likes: 2400, comments: 48, permalink: "#", caption: "", type: "IMAGE" as const, timestamp: "" },
  { id: "2", image: "https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=400&q=80", likes: 1800, comments: 32, permalink: "#", caption: "", type: "IMAGE" as const, timestamp: "" },
  { id: "3", image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?w=400&q=80", likes: 3100, comments: 67, permalink: "#", caption: "", type: "IMAGE" as const, timestamp: "" },
  { id: "4", image: "https://images.unsplash.com/photo-1511512578047-dfb367046420?w=400&q=80", likes: 2700, comments: 54, permalink: "#", caption: "", type: "IMAGE" as const, timestamp: "" },
];

const youtubeVideos = [
  {
    id: 1,
    thumbnail: "https://images.unsplash.com/photo-1493711662062-fa541f7f3d24?w=600&q=80",
    title: "REVELADO: O Futuro dos Consoles",
    views: "125K",
    duration: "18:32",
  },
  {
    id: 2,
    thumbnail: "https://images.unsplash.com/photo-1560253023-3ec5d502959f?w=600&q=80",
    title: "Investigação: Cripto e Games",
    views: "89K",
    duration: "24:15",
  },
];

function formatLikes(likes: number): string {
  if (likes >= 1000) {
    return `${(likes / 1000).toFixed(1)}K`;
  }
  return likes.toString();
}

const SocialIntegration = () => {
  const { data: instagramPosts, isLoading, isError } = useInstagramFeed(4);
  
  const posts = instagramPosts || fallbackInstagramPosts;

  return (
    <section className="py-20 relative">
      <div className="container px-4">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Instagram Section */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-purple-500 via-pink-500 to-orange-500 flex items-center justify-center">
                <Instagram className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-display font-bold text-xl">@geekfiles</h3>
                <p className="text-muted-foreground text-sm">Siga no Instagram</p>
              </div>
            </div>

            {isLoading ? (
              <div className="grid grid-cols-2 gap-3 mb-4">
                {[1, 2, 3, 4].map((i) => (
                  <div key={i} className="aspect-square rounded-xl bg-muted animate-pulse flex items-center justify-center">
                    <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
                  </div>
                ))}
              </div>
            ) : isError ? (
              <div className="grid grid-cols-2 gap-3 mb-4">
                {fallbackInstagramPosts.map((post) => (
                  <div key={post.id} className="group relative aspect-square rounded-xl overflow-hidden">
                    <img
                      src={post.image}
                      alt="Instagram post"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-background/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                      <span className="flex items-center gap-1 text-sm">
                        <Heart className="w-4 h-4 text-pink-500" /> {formatLikes(post.likes)}
                      </span>
                      <span className="flex items-center gap-1 text-sm">
                        <MessageCircle className="w-4 h-4 text-primary" /> {post.comments}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3 mb-4">
                {posts.map((post) => (
                  <a 
                    key={post.id} 
                    href={post.permalink} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="group relative aspect-square rounded-xl overflow-hidden"
                  >
                    <img
                      src={post.image}
                      alt={post.caption || "Instagram post"}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-background/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-4">
                      <span className="flex items-center gap-1 text-sm">
                        <Heart className="w-4 h-4 text-pink-500" /> {formatLikes(post.likes)}
                      </span>
                      <span className="flex items-center gap-1 text-sm">
                        <MessageCircle className="w-4 h-4 text-primary" /> {post.comments}
                      </span>
                    </div>
                  </a>
                ))}
              </div>
            )}

            <Button 
              className="w-full bg-gradient-to-r from-purple-500 via-pink-500 to-orange-500 text-white hover:opacity-90"
              onClick={() => window.open('https://instagram.com/geekfiles', '_blank')}
            >
              <Instagram className="w-4 h-4 mr-2" />
              Seguir no Instagram
            </Button>
          </div>

          {/* YouTube Section */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 rounded-xl bg-red-600 flex items-center justify-center">
                <Youtube className="w-6 h-6 text-white" />
              </div>
              <div>
                <h3 className="font-display font-bold text-xl">GeekFiles TV</h3>
                <p className="text-muted-foreground text-sm">45K inscritos</p>
              </div>
            </div>

            <div className="space-y-4 mb-4">
              {youtubeVideos.map((video) => (
                <div key={video.id} className="group flex gap-4 p-3 rounded-xl bg-card border border-border card-hover">
                  <div className="relative w-40 aspect-video flex-shrink-0 rounded-lg overflow-hidden">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-background/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="w-10 h-10 rounded-full bg-red-600 flex items-center justify-center">
                        <Play className="w-5 h-5 text-white ml-0.5" />
                      </div>
                    </div>
                    <span className="absolute bottom-1 right-1 px-1.5 py-0.5 bg-background/80 rounded text-xs">
                      {video.duration}
                    </span>
                  </div>
                  <div className="flex-1">
                    <h4 className="font-display font-semibold group-hover:text-primary transition-colors line-clamp-2">
                      {video.title}
                    </h4>
                    <p className="text-sm text-muted-foreground mt-1">{video.views} visualizações</p>
                  </div>
                </div>
              ))}
            </div>

            <Button className="w-full bg-red-600 text-white hover:bg-red-700">
              <Youtube className="w-4 h-4 mr-2" />
              Inscrever-se no Canal
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default SocialIntegration;
