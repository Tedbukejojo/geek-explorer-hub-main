import { Instagram, Youtube, Twitter, Github, Mail } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const links = {
    categories: [
      { name: "Gaming", href: "#gaming" },
      { name: "Tecnologia", href: "#tech" },
      { name: "Investigações", href: "#investigations" },
      { name: "Entretenimento", href: "#entertainment" },
    ],
    company: [
      { name: "Sobre Nós", href: "#about" },
      { name: "Contato", href: "#contact" },
      { name: "Anuncie", href: "#advertise" },
      { name: "Trabalhe Conosco", href: "#careers" },
    ],
    legal: [
      { name: "Termos de Uso", href: "#terms" },
      { name: "Privacidade", href: "#privacy" },
      { name: "Cookies", href: "#cookies" },
    ],
  };

  const social = [
    { icon: Instagram, href: "#", label: "Instagram" },
    { icon: Youtube, href: "#", label: "YouTube" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Github, href: "#", label: "GitHub" },
  ];

  return (
    <footer className="border-t border-border bg-card/50">
      <div className="container px-4 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-2">
            <a href="#" className="flex items-center gap-2 mb-4">
              <div className="w-10 h-10 rounded-lg bg-primary/20 border border-primary flex items-center justify-center">
                <span className="font-display font-bold text-primary text-lg">G</span>
              </div>
              <span className="font-display font-bold text-xl tracking-wider">
                <span className="text-primary">GEEK</span>
                <span className="text-secondary">FILES</span>
              </span>
            </a>
            <p className="text-muted-foreground text-sm mb-6 max-w-xs">
              O seu portal definitivo para o universo geek. Notícias, investigações e conteúdo exclusivo sobre games, tech e cultura pop.
            </p>
            <div className="flex gap-3">
              {social.map((item) => {
                const Icon = item.icon;
                return (
                  <a
                    key={item.label}
                    href={item.href}
                    aria-label={item.label}
                    className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center text-muted-foreground hover:bg-primary hover:text-primary-foreground transition-colors"
                  >
                    <Icon className="w-5 h-5" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-display font-semibold mb-4">Categorias</h3>
            <ul className="space-y-2">
              {links.categories.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-muted-foreground hover:text-primary text-sm transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-display font-semibold mb-4">Empresa</h3>
            <ul className="space-y-2">
              {links.company.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-muted-foreground hover:text-primary text-sm transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="font-display font-semibold mb-4">Legal</h3>
            <ul className="space-y-2">
              {links.legal.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-muted-foreground hover:text-primary text-sm transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="cyber-line my-8" />

        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <p>© {currentYear} GeekFiles. Todos os direitos reservados.</p>
          <a href="mailto:contato@geekfiles.com" className="flex items-center gap-2 hover:text-primary transition-colors">
            <Mail className="w-4 h-4" />
            contato@geekfiles.com
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
