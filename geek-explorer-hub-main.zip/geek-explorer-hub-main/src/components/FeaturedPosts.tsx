import { Clock, Eye, ArrowRight } from "lucide-react";
import { Badge } from "./ui/badge";

const posts = [
  {
    id: 1,
    title: "Os Segredos por Trás do Novo PlayStation 6",
    excerpt: "Investigamos os rumores e vazamentos sobre a próxima geração de consoles da Sony.",
    category: "Gaming",
    image: "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=800&q=80",
    readTime: "8 min",
    views: "12.5K",
    featured: true,
  },
  {
    id: 2,
    title: "IA e o Futuro dos Videogames",
    excerpt: "Como a inteligência artificial está revolucionando a indústria de games.",
    category: "Tecnologia",
    image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=800&q=80",
    readTime: "6 min",
    views: "8.2K",
    featured: false,
  },
  {
    id: 3,
    title: "Investigação: Empresas de Tech e Dados Pessoais",
    excerpt: "Um mergulho profundo nas práticas de coleta de dados das big techs.",
    category: "Investigação",
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&q=80",
    readTime: "12 min",
    views: "25.3K",
    featured: false,
  },
  {
    id: 4,
    title: "O Retorno dos Animes Clássicos",
    excerpt: "Por que os estúdios estão apostando em remakes de animes dos anos 90.",
    category: "Anime",
    image: "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=800&q=80",
    readTime: "5 min",
    views: "6.8K",
    featured: false,
  },
];

const FeaturedPosts = () => {
  const mainPost = posts[0];
  const sidePosts = posts.slice(1);

  return (
    <section className="py-20 relative">
      <div className="container px-4">
        <div className="flex items-center justify-between mb-12">
          <div>
            <h2 className="font-display text-3xl md:text-4xl font-bold mb-2">
              <span className="gradient-text">Em Destaque</span>
            </h2>
            <p className="text-muted-foreground">Os artigos mais lidos da semana</p>
          </div>
          <a href="#" className="hidden md:flex items-center gap-2 text-primary hover:gap-3 transition-all">
            Ver todos <ArrowRight className="w-4 h-4" />
          </a>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          {/* Main Featured Post */}
          <article className="group relative overflow-hidden rounded-2xl bg-card border border-border card-hover">
            <div className="aspect-[16/10] overflow-hidden">
              <img
                src={mainPost.image}
                alt={mainPost.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6">
              <Badge className="bg-primary/20 text-primary border-primary/30 mb-4">
                {mainPost.category}
              </Badge>
              <h3 className="font-display text-2xl md:text-3xl font-bold mb-3 group-hover:text-primary transition-colors">
                {mainPost.title}
              </h3>
              <p className="text-muted-foreground mb-4 line-clamp-2">{mainPost.excerpt}</p>
              <div className="flex items-center gap-4 text-sm text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" /> {mainPost.readTime}
                </span>
                <span className="flex items-center gap-1">
                  <Eye className="w-4 h-4" /> {mainPost.views}
                </span>
              </div>
            </div>
          </article>

          {/* Side Posts */}
          <div className="flex flex-col gap-4">
            {sidePosts.map((post) => (
              <article
                key={post.id}
                className="group flex gap-4 p-4 rounded-xl bg-card border border-border card-hover"
              >
                <div className="w-32 h-24 flex-shrink-0 overflow-hidden rounded-lg">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="flex-1 flex flex-col justify-center">
                  <Badge variant="outline" className="w-fit text-xs mb-2 border-secondary/30 text-secondary">
                    {post.category}
                  </Badge>
                  <h3 className="font-display font-semibold line-clamp-2 group-hover:text-primary transition-colors">
                    {post.title}
                  </h3>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mt-2">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {post.readTime}
                    </span>
                    <span className="flex items-center gap-1">
                      <Eye className="w-3 h-3" /> {post.views}
                    </span>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default FeaturedPosts;
