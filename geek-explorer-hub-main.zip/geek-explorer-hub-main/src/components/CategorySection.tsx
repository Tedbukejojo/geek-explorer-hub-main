import { Gamepad2, Search, Cpu, Film, ArrowRight } from "lucide-react";
import { Badge } from "./ui/badge";

const categories = [
  {
    id: "gaming",
    name: "Gaming",
    icon: Gamepad2,
    description: "Reviews, notícias e análises do mundo dos games",
    color: "primary",
    posts: 85,
  },
  {
    id: "investigations",
    name: "Investigações",
    icon: Search,
    description: "Reportagens investigativas sobre tecnologia e indústria",
    color: "secondary",
    posts: 42,
  },
  {
    id: "tech",
    name: "Tecnologia",
    icon: Cpu,
    description: "Hardware, software e as últimas inovações tech",
    color: "accent",
    posts: 68,
  },
  {
    id: "entertainment",
    name: "Entretenimento",
    icon: Film,
    description: "Filmes, séries, animes e cultura pop",
    color: "primary",
    posts: 55,
  },
];

const CategorySection = () => {
  return (
    <section id="geek" className="py-20 relative">
      {/* Background accent */}
      <div className="absolute inset-0 bg-gradient-to-b from-background via-muted/20 to-background" />

      <div className="container px-4 relative">
        <div className="text-center mb-12">
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            Explore por <span className="gradient-text-secondary">Categoria</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Navegue pelo conteúdo organizado por temas que mais te interessam
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {categories.map((category, index) => {
            const Icon = category.icon;
            const colorClasses = {
              primary: "border-primary/30 hover:border-primary bg-primary/5 hover:bg-primary/10 text-primary",
              secondary: "border-secondary/30 hover:border-secondary bg-secondary/5 hover:bg-secondary/10 text-secondary",
              accent: "border-accent/30 hover:border-accent bg-accent/5 hover:bg-accent/10 text-accent",
            };

            return (
              <a
                key={category.id}
                href={`#${category.id}`}
                className={`group p-6 rounded-2xl border transition-all duration-300 card-hover ${colorClasses[category.color as keyof typeof colorClasses]}`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-14 h-14 rounded-xl bg-background/50 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <Icon className="w-7 h-7" />
                </div>
                <h3 className="font-display font-bold text-xl mb-2 text-foreground">{category.name}</h3>
                <p className="text-muted-foreground text-sm mb-4">{category.description}</p>
                <div className="flex items-center justify-between">
                  <Badge variant="outline" className="border-current/30">
                    {category.posts} artigos
                  </Badge>
                  <ArrowRight className="w-4 h-4 opacity-0 group-hover:opacity-100 group-hover:translate-x-1 transition-all" />
                </div>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default CategorySection;
