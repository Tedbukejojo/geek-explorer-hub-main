import { ExternalLink, Star, TrendingUp } from "lucide-react";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";

const products = [
  {
    id: 1,
    name: "PlayStation 5 Standard",
    image: "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400&q=80",
    price: "R$ 4.299",
    originalPrice: "R$ 4.999",
    rating: 4.8,
    store: "amazon",
    badge: "Oferta",
  },
  {
    id: 2,
    name: "Nintendo Switch OLED",
    image: "https://images.unsplash.com/photo-1578303512597-81e6cc155b3e?w=400&q=80",
    price: "R$ 2.499",
    originalPrice: null,
    rating: 4.9,
    store: "mercadolivre",
    badge: "Popular",
  },
  {
    id: 3,
    name: "Headset Gamer HyperX",
    image: "https://images.unsplash.com/photo-1599669454699-248893623440?w=400&q=80",
    price: "R$ 599",
    originalPrice: "R$ 799",
    rating: 4.7,
    store: "amazon",
    badge: "-25%",
  },
  {
    id: 4,
    name: "Teclado Mecânico RGB",
    image: "https://images.unsplash.com/photo-1595225476474-87563907a212?w=400&q=80",
    price: "R$ 449",
    originalPrice: null,
    rating: 4.6,
    store: "mercadolivre",
    badge: null,
  },
];

const ShopSection = () => {
  return (
    <section id="shop" className="py-20 relative">
      <div className="absolute inset-0 bg-gradient-to-b from-background via-card/50 to-background" />

      <div className="container px-4 relative">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full border border-secondary/30 bg-secondary/5 mb-4">
            <TrendingUp className="w-4 h-4 text-secondary" />
            <span className="text-sm text-secondary font-medium">Links Afiliados</span>
          </div>
          <h2 className="font-display text-3xl md:text-4xl font-bold mb-4">
            Produtos <span className="gradient-text-secondary">Recomendados</span>
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Selecionamos os melhores produtos geek com ofertas exclusivas da Amazon e Mercado Livre
          </p>
        </div>

        {/* Store Badges */}
        <div className="flex justify-center gap-4 mb-8">
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-orange-500/10 border border-orange-500/30">
            <div className="w-6 h-6 rounded bg-orange-500 flex items-center justify-center text-xs font-bold text-white">
              A
            </div>
            <span className="text-sm font-medium text-orange-400">Amazon</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-500/10 border border-yellow-500/30">
            <div className="w-6 h-6 rounded bg-yellow-500 flex items-center justify-center text-xs font-bold text-black">
              ML
            </div>
            <span className="text-sm font-medium text-yellow-400">Mercado Livre</span>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <div
              key={product.id}
              className="group p-4 rounded-2xl bg-card border border-border card-hover"
            >
              <div className="relative aspect-square rounded-xl overflow-hidden mb-4 bg-muted">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {product.badge && (
                  <Badge className="absolute top-2 left-2 bg-secondary text-secondary-foreground">
                    {product.badge}
                  </Badge>
                )}
                <div
                  className={`absolute top-2 right-2 w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${
                    product.store === "amazon"
                      ? "bg-orange-500 text-white"
                      : "bg-yellow-500 text-black"
                  }`}
                >
                  {product.store === "amazon" ? "A" : "ML"}
                </div>
              </div>

              <div className="flex items-center gap-1 mb-2">
                <Star className="w-4 h-4 fill-yellow-500 text-yellow-500" />
                <span className="text-sm font-medium">{product.rating}</span>
              </div>

              <h3 className="font-display font-semibold mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                {product.name}
              </h3>

              <div className="flex items-baseline gap-2 mb-4">
                <span className="font-display font-bold text-xl text-primary">{product.price}</span>
                {product.originalPrice && (
                  <span className="text-sm text-muted-foreground line-through">
                    {product.originalPrice}
                  </span>
                )}
              </div>

              <Button
                variant="outline"
                className="w-full border-primary/30 text-primary hover:bg-primary/10 group/btn"
              >
                Ver Oferta
                <ExternalLink className="w-4 h-4 ml-2 group-hover/btn:translate-x-0.5 group-hover/btn:-translate-y-0.5 transition-transform" />
              </Button>
            </div>
          ))}
        </div>

        <p className="text-center text-xs text-muted-foreground mt-8">
          * Links afiliados. Ao comprar através dos nossos links, você ajuda a manter o blog sem custo adicional.
        </p>
      </div>
    </section>
  );
};

export default ShopSection;
