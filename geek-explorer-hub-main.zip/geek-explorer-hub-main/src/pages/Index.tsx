import Header from "@/components/Header";
import HeroSection from "@/components/HeroSection";
import FeaturedPosts from "@/components/FeaturedPosts";
import CategorySection from "@/components/CategorySection";
import SocialIntegration from "@/components/SocialIntegration";
import ShopSection from "@/components/ShopSection";
import Newsletter from "@/components/Newsletter";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <HeroSection />
        <FeaturedPosts />
        <CategorySection />
        <SocialIntegration />
        <ShopSection />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
